import os
import threading
from flask import Flask, request, jsonify, send_from_directory
from telegram import Bot, InlineKeyboardMarkup, InlineKeyboardButton, ParseMode
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
import firebase_admin
from firebase_admin import credentials, firestore

# Load environment variables
BOT_TOKEN = os.environ.get('TEHNOVA_BOT_TOKEN', '')
FIREBASE_KEY_PATH = os.environ.get('FIREBASE_KEY_PATH', None)
WEBAPP_BASE_URL = os.environ.get('WEBAPP_BASE_URL', 'http://localhost:5000')

if not BOT_TOKEN:
    raise RuntimeError('TEHNOVA_BOT_TOKEN environment variable not set')

# Initialize Firebase (optional)
db = None
if FIREBASE_KEY_PATH and os.path.exists(FIREBASE_KEY_PATH):
    if not firebase_admin._apps:
        cred = credentials.Certificate(FIREBASE_KEY_PATH)
        firebase_admin.initialize_app(cred)
    db = firestore.client()

bot = Bot(token=BOT_TOKEN)
app = Flask(__name__, static_folder='../', static_url_path='')

# --- Telegram handlers ---
def start(update, context):
    text = (
        'Welcome to TehNova Marketplace.\n'
        'Use /miniapp to open the marketplace or /play to play the Tap Game.\n'
        'Use /post to start listing an item.'
    )
    update.message.reply_text(text)

def miniapp_command(update, context):
    url = f"{WEBAPP_BASE_URL}/mini_app/index.html?user_id={update.effective_user.id}"
    keyboard = [[InlineKeyboardButton('Open Marketplace', web_app={'url': url})]]
    update.message.reply_text('Open the Mini App below:', reply_markup=InlineKeyboardMarkup(keyboard))

def play_game_command(update, context):
    url = f"{WEBAPP_BASE_URL}/game/index.html?user_id={update.effective_user.id}"
    keyboard = [[InlineKeyboardButton('Play Tap Game', web_app={'url': url})]]
    update.message.reply_text('Tap Game:', reply_markup=InlineKeyboardMarkup(keyboard))

def post_command(update, context):
    update.message.reply_text('To post an item, send: POST|Category|Title|Price|Description\nExample: POST|Electronics|Phone|30000|Good condition')

def generic_text_handler(update, context):
    text = update.message.text
    if text and text.startswith('POST|'):
        parts = text.split('|', 4)
        if len(parts) < 5:
            update.message.reply_text('Invalid format. Use: POST|Category|Title|Price|Description')
            return
        _, category, title, price, desc = parts
        seller_id = update.effective_user.id
        doc = {
            'category': category,
            'title': title,
            'price': price,
            'description': desc,
            'seller_id': seller_id,
            'seller_username': update.effective_user.username,
        }
        if db:
            db.collection('products').add(doc)
        update.message.reply_text('Item posted. Use /miniapp to view it in the marketplace.')
    else:
        update.message.reply_text("I didn't understand. Use /miniapp, /post, or /play.")

# Run updater in a thread
def run_updater():
    updater = Updater(BOT_TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler('start', start))
    dp.add_handler(CommandHandler('miniapp', miniapp_command))
    dp.add_handler(CommandHandler('play', play_game_command))
    dp.add_handler(CommandHandler('post', post_command))
    dp.add_handler(MessageHandler(Filters.text & ~Filters.command, generic_text_handler))
    updater.start_polling()
    updater.idle()

# --- REST API endpoints used by the WebApp ---
@app.route('/api/products', methods=['GET'])
def list_products():
    if db:
        col = db.collection('products').order_by('created_at', direction=firestore.Query.DESCENDING)
        docs = col.limit(100).stream()
        items = []
        for d in docs:
            data = d.to_dict()
            data['id'] = d.id
            items.append(data)
        return jsonify(items)
    else:
        return jsonify([])

@app.route('/api/products', methods=['POST'])
def create_product():
    body = request.json
    if not body:
        return jsonify({'error': 'invalid body'}), 400
    if db:
        body['created_at'] = firestore.SERVER_TIMESTAMP
        db.collection('products').add(body)
        return jsonify({'ok': True})
    else:
        return jsonify({'error': 'database not configured'}), 500

@app.route('/api/product/<product_id>/contact', methods=['POST'])
def contact_seller(product_id):
    payload = request.json or {}
    buyer_id = payload.get('buyer_id')
    message = payload.get('message', '')
    if not db:
        return jsonify({'error': 'database not configured'}), 500
    product_ref = db.collection('products').document(product_id).get()
    if not product_ref.exists:
        return jsonify({'error': 'product not found'}), 404
    p = product_ref.to_dict()
    seller_id = p.get('seller_id')
    try:
        text = (
            f"New inquiry for your item *{p.get('title')}* (ID: {product_id})\n"
            f"From buyer: `{buyer_id}`\n"
            f"Message: {message}"
        )
        bot.send_message(chat_id=seller_id, text=text, parse_mode=ParseMode.MARKDOWN)
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Serve static files (mini app and game)
@app.route('/mini_app/<path:filename>')
def mini_app_files(filename):
    return send_from_directory('../mini_app', filename)

@app.route('/game/<path:filename>')
def game_files(filename):
    return send_from_directory('../game', filename)

if __name__ == '__main__':
    t = threading.Thread(target=run_updater, daemon=True)
    t.start()
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
