# TehNovaBot — Marketplace Mini App + Tap Game

## What is included
- backend/bot.py — Flask + python-telegram-bot backend and REST API
- backend/requirements.txt — Python dependencies
- backend/.env.example — example environment variables
- mini_app/index.html — Marketplace WebApp (minimal)
- mini_app/css/styles.css — Simple styling
- game/index.html — Tap game (HTML/JS)
- LICENSE (MIT)

## Important — DO NOT commit secrets
This project **does not** include your bot token or Firebase service account.
Set environment variables on your server (or in a .env file) before running.

## Quick start (development)
1. Install Python 3.9+ and create a venv
    ```bash
    python -m venv venv
    source venv/bin/activate
    pip install -r backend/requirements.txt
    ```
2. Set environment variables (example in backend/.env.example)
    - TEHNOVA_BOT_TOKEN — Your bot token (e.g., 8590685115:AAH...)
    - FIREBASE_KEY_PATH — Path to Firebase service account JSON (optional if not using Firestore)
    - WEBAPP_BASE_URL — Public URL where mini_app and game will be served (e.g., https://your-domain.com)
3. Run the backend:
    ```bash
    cd backend
    python bot.py
    ```
4. Open Telegram, send /miniapp or /play to your bot.
